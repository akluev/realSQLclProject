alter table demo1.emp
    add constraint emp_foreign_key_on_job_job_id
        foreign key ( job_id )
            references demo1.job ( job_id )
        enable;


-- sqlcl_snapshot {"hash":"f650524d0b525ad0fbbb8cb5e846546af82e473c","type":"REF_CONSTRAINT","name":"EMP_FOREIGN_KEY_ON_JOB_JOB_ID","schemaName":"DEMO1","sxml":""}