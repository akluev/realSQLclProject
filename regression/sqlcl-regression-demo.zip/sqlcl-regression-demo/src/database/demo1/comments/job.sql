comment on table demo1.job is
    'Lookup table of employee job roles.';

comment on column demo1.job.color_class is
    'APEX Universal Theme color utility class for UI presentation (e.g. u-color-1).';

comment on column demo1.job.icon_class is
    'Font APEX icon class for UI presentation (e.g. fa-briefcase).';

comment on column demo1.job.job_code is
    'Short uppercase code for the job role (e.g. ANALYST, CLERK).';

comment on column demo1.job.job_id is
    'Primary key identifier for the job role.';

comment on column demo1.job.job_name is
    'Human-readable descriptive name of the job role.';


-- sqlcl_snapshot {"hash":"e8c9d7153f66256cb6f5dd7c8e67a74e93b5d096","type":"COMMENT","name":"job","schemaName":"demo1","sxml":""}