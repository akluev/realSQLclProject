comment on column demo1.dept.color_class is
    'APEX Universal Theme color utility class for UI presentation (e.g. u-color-1).';

comment on column demo1.dept.icon_class is
    'Font APEX icon class for UI presentation (e.g. fa-briefcase).';


-- sqlcl_snapshot {"hash":"ed5c4d82908be7296d9567de98d14ecee59777df","type":"COMMENT","name":"dept","schemaName":"demo1","sxml":""}