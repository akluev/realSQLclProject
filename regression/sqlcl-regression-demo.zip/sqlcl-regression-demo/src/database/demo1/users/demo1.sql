create user DEMO1 no authentication;



-- sqlcl_snapshot {"hash":"724366ac1c0db7570048ce367e3268d72f08a0f1","type":"USER","name":"DEMO1","schemaName":"CLA_DEPLOYER","sxml":""}