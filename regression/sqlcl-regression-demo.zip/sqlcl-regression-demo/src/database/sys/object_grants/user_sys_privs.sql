grant unlimited tablespace to demo1;


-- sqlcl_snapshot {"hash":"6137c95ec5aa033bda6f419d1474e4e3c30db273","type":"OBJECT_GRANT","name":"SYS_PRIVS","schemaName":"SYS","sxml":""}