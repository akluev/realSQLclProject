grant resource to demo1;

grant connect to demo1;


-- sqlcl_snapshot {"hash":"217a5b3e09555fcde16deaa8183e9c182a7c00bf","type":"OBJECT_GRANT","name":"ROLE_PRIVS","schemaName":"SYS","sxml":""}