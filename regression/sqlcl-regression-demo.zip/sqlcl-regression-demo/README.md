# SQLcl Regression Test Project

The SQLcl Project repository that the [SQLcl regression tests](https://github.com/akluev/realSQLclProject/tree/main/regression) run against. Do not develop in it: every test run resets git to the `baseline` tag and rebuilds the database objects.

## What it contains

- Schema `DEMO1` with tables `DEPT`, `EMP` and `JOB`, their constraints, comments and data.
- APEX workspace `DEMO1` with application 106 (EMP & DEPT Mini Hub), including static files with a mixed-case name and a spare page 100.
- ORDS: `DEMO1` is REST-enabled with module `regression.dept`, installed through `ORDS_ADMIN` by the custom changeset `dist/releases/1.0/changes/ords/_custom/ords_demo1.sql`. The ORDS export made with a schema connection (`src/database/demo1/ords/ords.sql`, `dist/releases/ords/`) is kept for the schema-connection tests but not installed; see `dist/releases/main.changelog.xml`.
- `.dbtools/filters/project.filters` keeps workarounds that the tests switch off between `--TEST-<id> BEGIN` and `--TEST-<id> END`.
- `.dbtools/project.config.json` sets the undocumented `stage.change.changeStyle` to `multiple`.

## Setup

1. Unpack it outside any other git repository and make sure `git status` is clean on `main` with tag `baseline`.
2. Create two saved SQLcl connections to a database you may rebuild:
   - an installer with DBA-like rights (creates users, APEX workspaces, ORDS through `ORDS_ADMIN`), e.g. `conn -save proj_vm26 ...`;
   - the schema itself, `DEMO1`, e.g. `conn -save demo_vm26 ...`. The password is set by `dist/releases/1.0/changes/new_base/cla_deployer/users/demo1.sql`.
3. Point `TEST_REPO`, `SQLCL_CONN` and `SCHEMA_CONN` in the regression `config.sh` at this folder and these connections, then run the reset once: `bash regression/reset/reset.sh`.
